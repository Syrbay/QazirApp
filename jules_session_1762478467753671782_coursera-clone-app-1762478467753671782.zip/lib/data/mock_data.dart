import '../models/category.dart';
import '../models/course.dart';
import '../models/lesson.dart';

final List<Category> mockCategories = [
  Category(id: '1', name: 'Computer Science', icon: '💻'),
  Category(id: '2', name: 'Business', icon: '💼'),
  Category(id: '3', name: 'Data Science', icon: '📊'),
  Category(id: '4', name: 'Personal Development', icon: '🌱'),
];

final List<Course> mockCourses = [
  Course(
    id: '101',
    title: 'Machine Learning Specialization',
    instructor: 'Andrew Ng',
    thumbnailUrl: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4',
    description: 'Learn the fundamentals of machine learning and build real-world AI applications.',
    rating: 4.9,
    studentsCount: 1500000,
    categoryId: '3',
    lessons: [
      Lesson(
        id: 'l1',
        title: 'Introduction to Machine Learning',
        duration: '10:00',
        videoUrl: 'https://example.com/video1',
        description: 'What is ML and why is it important?',
      ),
      Lesson(
        id: 'l2',
        title: 'Linear Regression',
        duration: '15:30',
        videoUrl: 'https://example.com/video2',
        description: 'Understanding linear relationships in data.',
      ),
    ],
  ),
  Course(
    id: '102',
    title: 'Introduction to Psychology',
    instructor: 'Steve Joordens',
    thumbnailUrl: 'https://images.unsplash.com/photo-1526628953301-3e589a6a8b74',
    description: 'Explore the fascinating world of the human mind and behavior.',
    rating: 4.8,
    studentsCount: 500000,
    categoryId: '4',
    lessons: [
      Lesson(
        id: 'l3',
        title: 'The History of Psychology',
        duration: '12:00',
        videoUrl: 'https://example.com/video3',
        description: 'How psychology became a science.',
      ),
    ],
  ),
  Course(
    id: '103',
    title: 'Financial Markets',
    instructor: 'Robert Shiller',
    thumbnailUrl: 'https://images.unsplash.com/photo-1611974715853-2b8ef9a36ceb',
    description: 'An overview of the ideas, methods, and institutions that permit human society to manage risks and foster enterprise.',
    rating: 4.8,
    studentsCount: 800000,
    categoryId: '2',
    lessons: [],
  ),
];
