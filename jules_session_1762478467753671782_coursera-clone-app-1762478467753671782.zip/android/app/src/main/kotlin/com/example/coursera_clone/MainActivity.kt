package com.example.coursera_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
