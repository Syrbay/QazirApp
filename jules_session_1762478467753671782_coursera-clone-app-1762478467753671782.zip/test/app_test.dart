import 'package:flutter_test/flutter_test.dart';
import 'package:coursera_clone/main.dart';
import 'package:coursera_clone/screens/home_screen.dart';

void main() {
  testWidgets('App should load and show home screen', (WidgetTester tester) async {
    await tester.pumpWidget(const CourseraCloneApp());
    
    expect(find.text('What do you want to learn?'), findsOneWidget);
    expect(find.byType(HomeScreen), findsOneWidget);
  });
}
