import 'lesson.dart';

class Course {
  final String id;
  final String title;
  final String instructor;
  final String thumbnailUrl;
  final String description;
  final double rating;
  final int studentsCount;
  final List<Lesson> lessons;
  final String categoryId;

  Course({
    required this.id,
    required this.title,
    required this.instructor,
    required this.thumbnailUrl,
    required this.description,
    required this.rating,
    required this.studentsCount,
    required this.lessons,
    required this.categoryId,
  });
}
