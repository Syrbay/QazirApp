class Lesson {
  final String id;
  final String title;
  final String duration;
  final String videoUrl;
  final String description;

  Lesson({
    required this.id,
    required this.title,
    required this.duration,
    required this.videoUrl,
    required this.description,
  });
}
