import 'package:flutter/material.dart';
import 'app.dart';

void main() {
  runApp(const CourseraCloneApp());
}

class CourseraCloneApp extends StatelessWidget {
  const CourseraCloneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Coursera Clone',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF0056D2), // Coursera Blue
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0056D2),
          primary: const Color(0xFF0056D2),
          secondary: const Color(0xFF0056D2),
        ),
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
        ),
        useMaterial3: true,
      ),
      home: const MainAppScreen(),
    );
  }
}
